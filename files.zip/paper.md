---
title: 'DRIADA: A Substrate-Agnostic Framework Bridging Single-Neuron Selectivity and Population Dynamics'
tags:
  - Python
  - neuroscience
  - calcium imaging
  - dimensionality reduction
  - mutual information
  - neural selectivity
  - artificial neural networks
  - interpretability
authors:
  - name: Nikita A. Pospelov
    orcid: 0000-0000-0000-0000
    affiliation: 1
affiliations:
 - name: Faculty of Physics, Lomonosov Moscow State University, Moscow, Russia
   index: 1
date: 3 January 2026
bibliography: paper.bib
---

# Summary

DRIADA (Dimensionality Reduction for Integrated Activity Data) is a Python framework that connects single-neuron selectivity analysis with population-level dimensionality reduction. The framework operates on neural activity data regardless of its source—calcium imaging recordings, electrophysiology, or artificial neural network activations. While neuroscience has increasingly adopted population-level approaches [@saxena2019towards], understanding how individual neuron properties contribute to collective representations remains methodologically challenging [@spalletti2022single]. DRIADA provides an integrated workflow linking information-theoretic selectivity testing at the single-cell level with manifold learning at the population level.

# Statement of Need

Analyzing neural computation requires tools that span both individual neurons and population dynamics, yet existing software addresses these scales separately. @quirogapanzeri2009 noted that "the complementary knowledge offered by decoding and information theory has not been exploited enough in neuroscience." This integration gap persists: @chung2021neural demonstrate that population manifold geometry "depends on the tuning curves of all neurons," explicitly linking single-neuron selectivity to population structure. No existing software provides a complete workflow to operationalize this connection.

**Information-theoretic toolboxes** provide mutual information estimation but do not integrate with dimensionality reduction. NIT [@maffulli2022nit] assumes Poisson statistics unsuitable for continuous calcium signals. MINT [@lorenz2025mint] analyzes information transmission at the population level without bridging to single-neuron selectivity. FRITES [@combrisson2022frites] implements group-level inference for EEG/MEG data. IDTxl [@wollstadt2019idtxl] focuses on network connectivity. HOI [@neri2024hoi] addresses higher-order interactions between variables.

**Population dimensionality reduction tools** extract latent representations but lack single-neuron selectivity statistics. CEBRA [@schneider2023learnable] produces consistent embeddings across modalities but operates purely at the population level. CILDS [@koh2023dimensionality] performs joint deconvolution and dimensionality reduction for calcium imaging without selectivity analysis. Demixed PCA [@kobak2016demixed] provides neuron contribution weights but lacks formal statistical tests for individual selectivity and is limited to categorical variables.

**DRIADA addresses this gap through:**

1. **Information Module**: Built on Gaussian Copula Mutual Information [@ince2017statistical], this module provides single-neuron selectivity analysis with two-stage statistical testing and Holm-Bonferroni correction [@holm1979simple]. The implementation supports interaction information and other multivariate measures through an efficient GCMI-based framework. Unlike correlation methods, it detects nonlinear relationships, handles temporal delays, and disentangles mixed selectivity when neurons respond to multiple correlated variables [@rigotti2013importance; @fusi2016why].

2. **Dimensionality Reduction Module**: Implements both classical methods (PCA, Factor Analysis) and manifold learning approaches (Isomap, UMAP [@mcinnes2018umap], Diffusion Maps). Includes a comprehensive autoencoder system with configurable architectures for neural network-based dimensionality reduction. Dimensionality estimation methods include PCA-based dimension, effective rank, k-NN dimension, and correlation dimension.

3. **Network Analysis Module**: Tools for analyzing functional connectivity structure in neural populations using graph-theoretic methods, including heat kernel affinities and giant component analysis.

4. **Signal Processing**: Calcium transient detection using synchrosqueezing wavelet transforms [@muradeli2020ssqueezepy] with GPU acceleration support.

5. **Substrate-Agnostic Design**: The framework analyzes activity from biological recordings and artificial neural networks identically. This follows @mante2013context, who applied identical analyses to prefrontal cortex and RNNs. Cross-domain tools such as RSA [@kriegeskorte2008representational] and CKA [@kornblith2019similarity] operate at the population level; DRIADA extends this to single-neuron selectivity testing across substrates.

6. **Validation Tools**: Synthetic data generators produce populations with known ground truth (head direction cells, place cells, mixed-selectivity neurons) for algorithm validation.

# Key Features and Implementation

The software architecture consists of:

- **Experiment Class**: Unified data container for neural recordings, behavioral variables, and analysis results
- **Information Engine**: GCMI-based mutual information with support for conditional MI, interaction information, and redundancy/synergy decomposition
- **Autoencoder System**: Configurable encoder-decoder architectures for nonlinear dimensionality reduction
- **Network Module**: Graph construction and analysis for functional connectivity
- **Manifold Learning**: Multiple algorithms with consistent interfaces

Performance optimization uses Numba JIT compilation and parallel processing via joblib. The codebase includes CI/CD workflows with automated testing.

# Research Applications

DRIADA has been applied to hippocampal and cortical calcium imaging data for analysis of place cells, head-direction cells, and mixed-selectivity populations during spatial navigation. The framework has also been used to analyze hidden unit activations in RNNs trained on navigation tasks, demonstrating applicability as an interpretability tool for artificial neural networks.

# Acknowledgements

We acknowledge feedback from the neuroscience community on the INTENSE methodology and from users who tested early versions of the framework.

# References
